<h1 align="center"> Mini Sistema de Aeroportos </h1>
<p align="center">Aqui você pode fazer suas reservas.</p>

### 🛠 Tecnologias

As seguintes ferramentas foram usadas na construção do projeto:

- [JavaScript](https://www.javascript.com/)
- [Node.js](https://nodejs.org/en/)
- [EJS](https://ejs.co/)
- [Bootstrap](https://getbootstrap.com/)
- [SQLite](https://www.sqlite.org/index.html)
